package com.melothemelon.crbuttons;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;

import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;

    ArrayList<SoundObject> soundList = new ArrayList<>();

    RecyclerView soundView;
    SoundboardRecyclerAdapter soundAdapter = new SoundboardRecyclerAdapter(soundList);
    RecyclerView.LayoutManager soundLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.soundboard_toolbar);
        setSupportActionBar(toolbar);

        List<String> nameList = Arrays.asList(getResources().getStringArray(R.array.soundNames));
        SoundObject[] soundItems = getSoundItemArray(nameList);
        soundList.addAll(Arrays.asList(soundItems));

        soundView = (RecyclerView) findViewById(R.id.soundboardRecyclerView);
        soundLayoutManager = new GridLayoutManager(this, 3); //3 is the amount of buttons per row
        soundView.setLayoutManager(soundLayoutManager);
        soundView.setAdapter(soundAdapter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventHanlderClass.releaseMediaPlayer();
    }

    private void requestPermissions(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            if(ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
            if(!Settings.System.canWrite(this)){

            }
        }
    }

    private SoundObject[] getSoundItemArray(List<String> nameList) {
        SoundObject[] soundItems = {new SoundObject(nameList.get(0), R.raw.beer),
                new SoundObject(nameList.get(1), R.raw.doigettohitthings),
                new SoundObject(nameList.get(2), R.raw.fixhim),
                new SoundObject(nameList.get(3), R.raw.grogstrongjaw),
                new SoundObject(nameList.get(4), R.raw.iapproveofthisplan),
                new SoundObject(nameList.get(5), R.raw.intelligenceof6),
                new SoundObject(nameList.get(6), R.raw.likeaflowergirl),
                new SoundObject(nameList.get(7), R.raw.liketorage),
                new SoundObject(nameList.get(8), R.raw.nice),
                new SoundObject(nameList.get(9), R.raw.nobodydiesaroundvoxmachina),
                new SoundObject(nameList.get(10), R.raw.profgrog),
                new SoundObject(nameList.get(11), R.raw.themeatoutofyourdome),
                new SoundObject(nameList.get(12), R.raw.touchmyaxe)};
        return soundItems;
    }
}