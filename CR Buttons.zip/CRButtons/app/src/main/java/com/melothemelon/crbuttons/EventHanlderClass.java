package com.melothemelon.crbuttons;

import android.media.MediaPlayer;
import android.util.Log;
import android.view.View;
import android.widget.PopupMenu;

public class EventHanlderClass {
    private static final String LOG_TAG = "EVENTHANDLER";
    private static MediaPlayer mediaPlayer;

    public static void startMediaPlayer(View view, Integer soundID){
        try{
            if(soundID != null){
                if(mediaPlayer != null)
                    mediaPlayer.reset();
                mediaPlayer = MediaPlayer.create(view.getContext(), soundID);
                mediaPlayer.start();
            }
        }catch(Exception e){
            Log.e(LOG_TAG, "Failed to initialize Media Player: " + e.getMessage());
        }
    }

    public static void releaseMediaPlayer(){
        if(mediaPlayer != null){
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    public static void popupManager(final View view, final SoundObject soundObject){
        PopupMenu popup = new PopupMenu(view.getContext(), view);
        popup.getMenuInflater().inflate(R.menu.longclick, popup.getMenu());
        popup.show();
    }

}
